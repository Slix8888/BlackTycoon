# JavaScript-Snake-Game

JavaScript Snake game sources 
http://zetcode.com/javascript/snake/

